<?php 

$file = 'counter.txt';
$fh = fopen($file, 'r+');
$id = $_REQUEST['id']; 
$lines = '';
while(!feof($fh)){
	$line = explode('||', fgets($fh));
	$item = trim($line[0]);
	$num = trim($line[1]);
	if(!empty($item)){
		if($item == $id){
			$num++; 
			echo $num;
			}
		$lines .= "$item||$num\r\n";
		}
	} 
file_put_contents($file, $lines);
fclose($fh);

?>	