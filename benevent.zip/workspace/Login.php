<?php
    //When starting mySQL make sure to use "mysql-ctl start" and not "mysql-ctl install"
  session_start();
   if($_SESSION["username"] != ''){
       header('Location: https://benevent-darrenq.c9users.io/');
   }
    
    $servername = 'localhost';
    $username = 'root';
    $password = "";
    $database = "Log in";
    $dbport = 3306;
    //$_SESSION["username"]= "xxx";
   
    // Create connection
    $db = new mysqli($servername, $username, $password, $database, $dbport);

    // Check connection
    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    } 
   // echo "Connected successfully (".$db->host_info.")";
    
    //IF Logging
    if(isset($_GET['tag'])){
        $tag = $_GET['tag'];
        
        $email = $_GET['emailname'];
        $password = $_GET['password'];
        
        if($tag == 'login' && $email != '' && $password != ''){
            
            $_session['status']=='loggedin';
            $query = "SELECT * FROM users WHERE email='$email' AND password='$password' ";
        
            $user = mysqli_query($db, $query);

            if(mysqli_num_rows($user) > 0){
                while($row = mysqli_fetch_array($user,MYSQLI_ASSOC)){
    				$_SESSION['username']=$row['username'];
                    echo '<script> alert('.$_SESSION['username'].')</script>';
                    break;
    			}
    			header('Location: https://benevent-darrenq.c9users.io/');
                
               // 
            }else{
                echo '<script> alert("Your User Name or Passwword are incorrect, Please try again !"); </script>';
            }
        }
        else{
            
        }
    }
    //IF Registering
    else if(isset($_POST['tag'])){
        $tag = $_POST['tag'];
        
        $email = $_POST['emailname'];
        $password = $_POST['password'];
        $username = $_POST['username'];
        $firstname = $_POST['firstname'];
        
        if($tag == 'register' && $email != '' && $password != '' && $username != '' ){
            
            $query = "INSERT INTO users(username, password, first_name, email) VALUES('$username','$password', '$firstname', '$email') ";
        
            $user = mysqli_query($db, $query);
            
            if($user){
                header('Location: https://benevent-darrenq.c9users.io/Login.php');
            }else{
                echo '<script> alert("Please check your details"); </script>';
            }
        }
        else{
            echo '<script> alert("Please check your details"); </script>';
        }
       
       
    }


// $con = mysql_connect("darrenq","cis_id","password");
// if (!$con)
//   {
//   die('Could not connect: ' . mysql_error());
//   }
 
// mysql_select_db("cis_id", $con);
 
// $sql="INSERT INTO nametable (fname, lname)
// VALUES
// ('$_POST[fname]','$_POST[lname]')";
 
// if (!mysql_query($sql,$con))
//   {
//   die('Error: ' . mysql_error());
//   }
// echo "1 record added";
 
// mysql_close($con)


?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title> Benevent </title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <style type="text/css">
        h2{color:white;}
    </style>
</head>

<body>

    <!-- Navigation -->
        
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                </button>
                <h2>Login Page </h2>
            </div>
            
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.php">Home Page</a></li>
            </div>
        </div>
    </nav>
    
    <div class="row">
        <div id="topBumper" class="col-lg-12">
            
        </div>
    </div>
    <div align="center">
        <div class="row">
            <div id="Wrap" class="col-lg-12">
            
                    <div class="col-sm-2" >
                     
                    </div>
            
                    <div class="col-lg-3">
                       text-align:left; <div id="login">
                <form action="" method="GET">
                    <input hidden name="tag" value="login" />
                    <h2> Log In </h2>
                    Email Address:<br>
                    <input type="text" name="emailname"><br>
                    Password:<br>
                    <input type="password" name="password"><br>
                    <br>
            <div id="submit"> 
                <input type='submit' name='Submit' value='Submit' />
            </div>    
            </form>
          </div>
            </div>
                
                    <div class="col-sm-2" >
                     
                    </div>
                    
            
            
                   <div class="col-lg-3">
                <div id="register">
            <form action="" method="POST">
                    <input hidden name="tag" value="register" />
                    <h2> Register </h2>
                    User Name:<br>
                    <input type="text" name="username"><br>
                    Name:<br>
                    <input type="text" name="firstname"><br>
                    Email Address:<br>
                    <input type="text" name="emailname"><br>
                    Password:<br>
                    <input type="password" name="password"><br>
                    Re-Enter Password:<br>
                    <input type="password" name="re-enter password"><br>
                    <br>
                    <div id="submit">        
                    <input type='submit' name='Submit' value='Submit' />
                    </div>    
            </form>
            </div>
            </div>
                    <div class="col-sm-2">
                
                    </div>
            
            </div>
            </div>
    
</body>

</html>

            
            