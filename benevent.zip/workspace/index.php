<?php
//include('login.php'); // Includes Login Script
 session_start();
//$_SESSION['username']='';
if(isset($_SESSION['username'])){
    //header("location: profile.php");
}

  // $_SESSION['username']=$username;
 
    session_start();
    session_destroy();
    //$_SESSION=array();
   // header("Location: Login.php");
   // exit;
   //if(session['logged']==true)
  // {
    //   echo $_session["username"];
    //echo '<a href="Login.php"><span>Logout' <li><a href="#">Hello, <?php echo $_SESSION["username"]; 
  

  
  ?>

<!DOCTYPE html>

<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Modern Business - Start Bootstrap Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
<style>

table,th,td {
  border : 1px solid black;
  border-collapse: collapse;
}
th,td {
  padding: 5px;
}

.page-content { padding:1em; max-width:64em; margin:auto }

.click-count { color:green; font-weight:bold }


</style>
<!-- moodle notes and w3schools -->
<script>
function loadDoc() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      myFunction(xhttp);
    }
  };
  xhttp.open("GET", "event.xml", true);
  xhttp.send();
}
function myFunction(xml) {
  var i;
  var xmlDoc = xml.responseXML;
  var table="<tr><th>Charity</th><th>Event</th><th>Location</th></tr>";
  var x = xmlDoc.getElementsByTagName("event");
  for (i = 0; i <x.length; i++) { 
    table += "<tr><td>" +
    x[i].getElementsByTagName("firstname")[0].childNodes[0].nodeValue +
    "</td><td>" +
    x[i].getElementsByTagName("lastname")[0].childNodes[0].nodeValue +
    "</td><td>"+
     x[i].getElementsByTagName("eventname")[0].childNodes[0].nodeValue +
    "</td></tr>";
  }
  document.getElementById("demo").innerHTML = table;
}

</script>

         <style>
       #map {
       width:80%;
       height:400px;
       }
    </style>
    
    <script>
function clickCounter() {
    if(typeof(Storage) !== "undefined") {
        if (localStorage.clickcount) {
            localStorage.clickcount = Number(localStorage.clickcount)+1;
        } else {
            localStorage.clickcount = 1;
        }
        document.getElementById("result").innerHTML = "You have clicked the button " + localStorage.clickcount + " time(s).";
    } else {
        document.getElementById("result").innerHTML = "Sorry, your browser does not support web storage...";
    }
}
</script>
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="event.php" >Create Event</a>
        
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        
                        <?php
                            if($_SESSION['username'] =='' || $_SESSION['username'] == null){
                        ?>
                            <a class="navbar-brand" href="Login.php">Login</a>
                        <?php
                            }
                            else{
                        ?>
                            <a class="navbar-brand" href="Profile.php"><?php echo $_SESSION['username']; ?></a>
                        <?php
                            }
                        ?>
                        
                         <a class="navbar-brand" href="index.php">Log Out</a>
                         
                        <ul class="dropdown-menu">
                            <li>
                                <a href=map.html>Map</a>
                            </li>
                            <li>
                                <a href="portfolio-2-col.html">2 Column Portfolio</a>
                            </li>
                            <li>
                                <a href="portfolio-3-col.html">3 Column Portfolio</a>
                            </li>
                            <li>
                                <a href="portfolio-4-col.html">4 Column Portfolio</a>
                            </li>
                            <li>
                                <a href=#myCarousel>Back to the top!</a>
                            </li>
                        </ul>
                    </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Header Carousel -->
    <header id="myCarousel" class="carousel slide">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
             <li data-target="#myCarousel" data-slide-to="3"></li>
        </ol>

        <!--Images for the slider at the top of the main page -->
        <div class="carousel-inner">
            <div class="item active">
                <img src = "/images/charity.jpg" style="width:100%;height:100%;">
                <div class="carousel-caption">
                   
                </div>
            </div>
            <div class="item">
                <img src = "images/l_Event7.jpg" alt="Event" style="width:100%;height:100%;">
                <div class="carousel-caption">
                   
                </div>
            </div>
            
            <div class="item">
                <img src = "images/download.jpg" alt = "Event" style="width:100%;height:100%;" >
      <div class="carousel-caption">
         
                </div>
            </div>
         
                <div class="item">
                <img src = "images/breast-cancer-fundraiser.jpg" alt = "Event" style="width:100%;height:100%;" >
      <div class="carousel-caption">
         
                </div>
            </div>
        </div>

        <!-- Controls for image slider -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>
    </header>

    <!-- Page Content -->
    <div class="container">

        <!-- Marketing Icons Section -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                <div align="center"><font face="Eras"><u>Benevent</u></font><br>
                </h1></div>
            </div>
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="0">
                    
                    
                    <!--About section on the website-->
                          <div align="center">
                        <h3><i class=""></i> &#9812; About</h3>
                    </div>
                    
                    <div class="panel-body">
                            <div align="center">
            <p><i><h4>  Benevent was established in 2016 to assist charities in fundraising.</i></h4> </p>
            <p><i><h4>  Our aim is to provide the right publicity for both charities and fundraisers to help raise funds for much needed causes. 
                        Charities can easily create fundraising pages through our Benevent website.
                        We allow Charities to publicize their events and will allow users to show interest in Events that are displayed on Benevent.</h3></i></p>
            <p><i><h4>  Benevent is a simple website that allows anyone who is interested to create and advertise their own events to raise money for a chairty of their choice.
                        The events hosted on Benevent will consist of everything from Bake Sales to Marathons. The map is featured on the website so that anyone looking to search for the location of events can do so very easily.
                        This will allow anyone who is interested to find events quickly.
            </h4></i></p>
                    </div>
                    </div>
                    </div>
                </div>
            </div>
            
            <!-- /.row -->
            
            <div class="page-content">

<br/>

<?php 

$clickcount = explode("\n", file_get_contents('counter.txt'));
foreach($clickcount as $line){
	$tmp = explode('||', $line);
	$count[trim($tmp[0])] = trim($tmp[1]);
	}

?>

<button class="click-trigger" data-click-id="click-001">Like Our Page Button!</button> 
Clicked <span id="click-001" class="click-count"><?php echo $count['click-001'];?></span> times.

<br/><br/>



<script>
var clicks = document.querySelectorAll('.click-trigger'); // IE8
for(var i = 0; i < clicks.length; i++){
	clicks[i].onclick = function(){
		var id = this.getAttribute('data-click-id');
		var post = 'id='+id; // post string
		var req = new XMLHttpRequest();
		req.open('POST', 'counter.php', true);
		req.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		req.onreadystatechange = function(){
			if (req.readyState != 4 || req.status != 200) return; 
			document.getElementById(id).innerHTML = req.responseText;
			};
		req.send(post);
		}
	}
</script>




        <!-- Portfolio Section -->
        <div class="row">
            <div class="col-lg-12">
                    <div align="center">
                <h1 class="page-header"><font face="Eras"><u>Events</u></h1>
                </div>
            </div>
            <div class="col-sm-12">
               
                    <img class="img-responsive img-portfolio img-hover" src = "images/UpcomingEvents.jpg" alt = "Event" style="width:1300px;height:425px;max-width:100%;" onclick="loadDoc()" 
                    alt="">
                        </a>

                    <br><br>
                    <table id="demo"></table>
                    <br><br>
         </div>
                
            </div>
            <div class="col-sm-12">
                
                    <img class="img-responsive img-portfolio img-hover" src="images/people.jpg" alt="">
                </a>
                 <hr>
           </div>
             
             
             
        <?php
            
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "Log in";
            $dbport = "3306";
            
            $con = mysqli_connect("localhost", "root", "", "Log in", "3306")or die(mysqli_connect_error());
    
            $query="SELECT * FROM Events";
    
             $result=mysqli_query($con,$query);
                echo "<table border=1>";
             while($row= mysqli_fetch_array($result))
            {
  
               echo "<tr>";
                echo "<td>" .$row["Email"] . "</td>";
                echo "<td>".$row["Name"] . "</td>";
                echo "<td>".$row["Charity"] . "</td>";
                echo "<td>".$row["Location"] . "</td>";
                echo "<td>".$row["Description"] . "</td>";
                echo "</tr>";
            }
             echo "<table>";
            mysqli_close($con);
            ?>
            
        </div>
        <!-- /.row -->

        <!-- Features Section -->
        <div class="row">
            <div class="col-lg-12">
                   <div align="center"> <h2 class="page-header"><b><u>Map</u></b></h2></div>
            </div>
            <!--<div id="out"></div>-->
            <!--<input onclick="clearMarkers();" type=button value="Hide Markers">
            <input onclick="showMarkers();" type=button value="Show All Markers">-->
            <div class="col-md-0"></div>
            <div class="col-md-12">
            <div align="center"><div id="map"></div></div>
            <div id="message"><p>To add a marker click on a location,</br> to give details to be saved to a databased click on the marker.</p></div>
                 <!-- Add Google Maps -->
                </div>
            </div>
        </div>
        <!-- /.row -->
<hr>
        <!-- Call to Action Section -->
        <div class="well">
            <div class="row">
                <div class="col-md-12">
                    <p></p>
                </div>
                
            </div>
        </div>

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>
                           <div align="center">
                        Copyright &copy; Benevent 2016   <div class="col-md-4">
                            </div>
                    <a class="btn btn-lg btn-default btn-block" href="#">Return to Top</a>
                </div>
                </p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    <!--Map--->
    <!--<script src="map.js"></script>-->
    <script type="text/javascript" async defer
    src="//maps.googleapis.com/maps/api/js?key=AIzaSyB9tzYAHrfiYR6q1bkPDzWt4y-FTJvLoeg&callback=init">
    </script>


    <!--Code to run map-->
    <script>
    var marker;
    var infowindow;

    function init() {
      var latlng = new google.maps.LatLng(53.337203, -6.265640);
      var options = {
        zoom: 11,
        center: latlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      var map = new google.maps.Map(document.getElementById("map"), options);
      var html = "<table>" +
                 "<tr><td>Name:</td> <td><input type='text' id='name'/> </td> </tr>" +
                 "<tr><td>Address:</td> <td><input type='text' id='address'/></td> </tr>" +
                 "</select> </td></tr>" +
                 "<tr><td></td><td><input type='button' value='Save & Close' onclick='saveData()'/></td></tr>";
    infowindow = new google.maps.InfoWindow({
     content: html
    });

    google.maps.event.addListener(map, "click", function(event) {
        marker = new google.maps.Marker({
          position: event.latLng,
          map: map
        });
        google.maps.event.addListener(marker, "click", function() {
          infowindow.open(map, marker);
        });
    });
    }
    
    
    function bindInfoWindow(marker, map, infoWindow, html) {
      google.maps.event.addListener(marker, 'click', function() {
        infoWindow.setContent(html);
        infoWindow.open(map, marker);
      });
    }
    function downloadUrl(url, callback) {
      var request = window.ActiveXObject ?
          new ActiveXObject('Microsoft.XMLHTTP') :
          new XMLHttpRequest;
      request.onreadystatechange = function() {
        if (request.readyState == 4) {
          request.onreadystatechange = doNothing;
          callback(request, request.status);
        }
      };
      request.open('GET', url, true);
      request.send(null);
    }
    
    function saveData() {
      var name = escape(document.getElementById("name").value);
      var address = escape(document.getElementById("address").value);
      var type = document.getElementById("type").value;
      var latlng = marker.getPosition();

      var url = "markers.php?name=" + name + "&address=" + address +
                 "&lat=" + latlng.lat() + "&lng=" + latlng.lng();
      downloadUrl(url, function(data, responseCode) {
        if (responseCode == 200 && data.response.length >= 1) {
          infowindow.close();
          document.getElementById("message").innerHTML = "Location added.";
        }
      });
    }

    function downloadUrl(url, callback) {
      var request = window.ActiveXObject ?
          new ActiveXObject('Microsoft.XMLHTTP') :
          new XMLHttpRequest;

      request.onreadystatechange = function() {
        if (request.readyState == 4) {
          request.onreadystatechange = doNothing;
          callback(request.responseText, request.status);
        }
      };

      request.open('GET', url, true);
      request.send(null);
    }

    function doNothing() {}
    </script>
    
    
    <!-- Script to Activate the Carousel -->
    <script>
    $('.carousel').carousel({
        interval: 5000 //changes the speed
    })
    </script>
    
    

</body>

</html>