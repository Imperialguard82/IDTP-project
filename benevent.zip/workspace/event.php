<?php
    //When starting mySQL make sure to use "mysql-ctl start" and not "mysql-ctl install"
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "Log in";
    $dbport = "3306";
    
    //Creating a Connection
    $db = new mysqli($servername, $username, $password, $database, $dbport);
    
    //Checking the Connection
    if ($db->connect_error) {
        die("Connection Failed: " . $db->connect-error);
    }
    
    //When Creating The Event
    if(isset($_POST['tag'])){
        $tag = $_POST['tag'];
        
        //Names of variables
        $Email = $_POST['emailname'];
        $Name = $_POST['name_of_Event'];
        $Charity = $_POST['charity'];
        $Description = $_POST['desc'];
        $Location = $_POST['location'];
        
        //Checking the form for details
        if($tag == 'eventcreate' && $Email != '' && $Name != '' && $Charity != '' && $Location != '' && $Description != ''){
            
            //Inserting the values into the Database
            $query = "INSERT INTO Events(Email,Name, Charity, Location, Description) VALUES('$Email','$Name','$Charity','$Location','$Description')"; 
            
            $user = mysqli_query($db, $query);
            
            //If the details are correct user is brought to the main page
            if($user){
                header('Location: https://benevent-darrenq.c9users.io/index.php');
                
            //Else an alert pops up and users is asked to check that the details are correct
            }else{
                echo '<script> alert("This is an alert);</script>';
            }
        }
        //Alerting the user about their details
        else{
            echo '<script> alert("Please check your details"); </script>';
        }
    }
?>

<html lang="en">
    
<head>
    
    <!--Title of the browser tab-->
    <title>Benevent - Create Event</title>
    
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <style type="text/css">
        h2{color:white;}
    </style>
    
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <div class="container">

        <!-- Marketing Icons Section -->
        <div class="row">
            <div class="col-lg-12">
                
            </div>
            <div class="col-md-12">
                <div class="panel panel-default">
                <!--    <div class="0">
                    </div> -->
            
            <div class="page-content">

        <!-- Portfolio Section -->
        <div class="row">

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    <!--Navigation bar at the top of the page-->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <!--Button for collapsing list when web page is minimised-->
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                </button>
                <h2>Create Events</h2>
            </div>
            
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.php">Home Page</a></li>
            </div>
        </div>
    </nav>
    
        <!--Empty div used for pushing the forms into place-->
        <div id="topBumper" class="col-lg-12">
        </div>    
            
            <div class="row, col-md-12" style="background-color:#333; border-radius:25px;">
                <div class= "col-sm-4">
                </div>
                <div class="col-lg-4">
                <!--Form used for creation of the events-->
                <form action="" method="POST">
                    
                    <input hidden name="tag" value="eventcreate" />
                    
                    <h2> Events</h2>
                    
                    <font color="orange">
                    
                    Email Address:<br>
                    <input type="text" name="emailname" placeholder="sample@gmail.com"><br>
                    Name of Event:<br>
                    <input type="text" name="name_of_Event" placeholder="Benvent Event"><br>
                    Charity:<br>
                    <input type="text" name="charity" placeholder="Charity"><br>
                    Address:<br>
                    <input type="text" name="location" placeholder="22 kilbarron road, Coolock, Dublin 5"><br>
                    Description:<br>
                    <textarea rows="3" cols="30" name="desc" placeholder="Science."></textarea>
                    
                    <br>
                
                    <!--Button used for submitting the details of the events form-->
                    <div id="submit">
                        <input type='submit' name='Submit' value='Submit' />
                    </div>
                    </form>
                    <div class= "col-sm-4">
                </div>
            </div>
            
            
            
</body>

</html>